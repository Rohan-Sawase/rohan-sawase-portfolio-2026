import { motion } from 'framer-motion';
import { Briefcase, CheckCircle2 } from 'lucide-react';
import SectionHeading from './SectionHeading';

const responsibilities = [
  'Developed web development projects',
  'Worked on responsive UI design',
  'Improved frontend development skills',
  'Learned practical software development workflow',
  'Collaborated on project implementation',
];

export default function Experience() {
  return (
    <section id="experience" className="section-pad relative">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <SectionHeading eyebrow="Where I've worked" title={<>Experience</>} icon={<Briefcase size={15} />} />

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7 }}
          className="relative glass rounded-3xl p-6 sm:p-10 overflow-hidden"
        >
          <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full gradient-primary opacity-20 blur-3xl" />

          <div className="relative flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6 mb-6">
            <div className="h-16 w-16 shrink-0 rounded-2xl gradient-primary flex items-center justify-center text-white glow">
              <Briefcase size={28} />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="font-display font-bold text-xl sm:text-2xl">Web Development Intern</h3>
                <span className="text-xs font-semibold px-3 py-1 rounded-full gradient-primary text-white">CodSoft</span>
              </div>
              <p className="text-muted text-sm mt-1">April 2024 – May 2024</p>
            </div>
          </div>

          <div className="relative grid sm:grid-cols-2 gap-3">
            {responsibilities.map((r, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className="flex items-start gap-3 p-3 rounded-xl glass glass-hover"
              >
                <CheckCircle2 size={18} className="text-[#3B82F6] shrink-0 mt-0.5" />
                <span className="text-sm">{r}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
